const GFCB = artifacts.require("GFCB")
module.exports = async function(callback) {
  try {
    await web3.eth.getAccounts().then(function (acc){accounts = acc})
    result = []
    instance = await GFCB.deployed()
    address = await GFCB.address
    try{
      result[1] = await instance.transfer(accounts[18], web3.utils.toBN("100000000000000000000"), {from: accounts[0], value: web3.utils.toWei("0")})
    console.log("1")
    console.log(result[1])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[2] = await instance.transfer(accounts[0], web3.utils.toBN("100000000000000000000"), {from: accounts[18], value: web3.utils.toWei("0")})
    console.log("2")
    console.log(result[2])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[3] = await instance.transfer(accounts[6], web3.utils.toBN("33333333000000000000000000"), {from: accounts[0], value: web3.utils.toWei("0")})
    console.log("3")
    console.log(result[3])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[4] = await instance.transfer(accounts[7], web3.utils.toBN("3703703000000000000000000"), {from: accounts[6], value: web3.utils.toWei("0")})
    console.log("4")
    console.log(result[4])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[5] = await instance.transfer(accounts[14], web3.utils.toBN("740741000000000000000000"), {from: accounts[7], value: web3.utils.toWei("0")})
    console.log("5")
    console.log(result[5])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[6] = await instance.transfer(accounts[8], web3.utils.toBN("185185185000000000000000"), {from: accounts[14], value: web3.utils.toWei("0")})
    console.log("6")
    console.log(result[6])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[7] = await instance.transfer(accounts[13], web3.utils.toBN("80000000000000000000000"), {from: accounts[6], value: web3.utils.toWei("0")})
    console.log("7")
    console.log(result[7])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[8] = await instance.transfer(accounts[1], web3.utils.toBN("20000000000000000000000"), {from: accounts[6], value: web3.utils.toWei("0")})
    console.log("8")
    console.log(result[8])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[9] = await instance.transfer(accounts[15], web3.utils.toBN("37037000000000000000000"), {from: accounts[14], value: web3.utils.toWei("0")})
    console.log("9")
    console.log(result[9])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[10] = await instance.transfer(accounts[9], web3.utils.toBN("18518000000000000000000"), {from: accounts[14], value: web3.utils.toWei("0")})
    console.log("10")
    console.log(result[10])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[11] = await instance.transfer(accounts[5], web3.utils.toBN("1043118000000000000000000"), {from: accounts[0], value: web3.utils.toWei("0")})
    console.log("11")
    console.log(result[11])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[12] = await instance.transfer(accounts[11], web3.utils.toBN("37000000000000000000000"), {from: accounts[5], value: web3.utils.toWei("0")})
    console.log("12")
    console.log(result[12])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[13] = await instance.transfer(accounts[2], web3.utils.toBN("27196000000000000000000"), {from: accounts[0], value: web3.utils.toWei("0")})
    console.log("13")
    console.log(result[13])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[14] = await instance.transfer(accounts[19], web3.utils.toBN("400000000000000000000000"), {from: accounts[5], value: web3.utils.toWei("0")})
    console.log("14")
    console.log(result[14])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[15] = await instance.transfer(accounts[3], web3.utils.toBN("35000000000000000000000"), {from: accounts[5], value: web3.utils.toWei("0")})
    console.log("15")
    console.log(result[15])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[16] = await instance.transfer(accounts[10], web3.utils.toBN("35000000000000000000000"), {from: accounts[3], value: web3.utils.toWei("0")})
    console.log("16")
    console.log(result[16])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[17] = await instance.transfer(accounts[20], web3.utils.toBN("74100000000000000000000"), {from: accounts[5], value: web3.utils.toWei("0")})
    console.log("17")
    console.log(result[17])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[18] = await instance.transfer(accounts[12], web3.utils.toBN("111000000000000000000000"), {from: accounts[5], value: web3.utils.toWei("0")})
    console.log("18")
    console.log(result[18])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[19] = await instance.transfer(accounts[17], web3.utils.toBN("370000000000000000000000"), {from: accounts[5], value: web3.utils.toWei("0")})
    console.log("19")
    console.log(result[19])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[20] = await instance.transfer(accounts[16], web3.utils.toBN("29529630000000000000000000"), {from: accounts[6], value: web3.utils.toWei("0")})
    console.log("20")
    console.log(result[20])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[21] = await instance.transfer(accounts[4], web3.utils.toBN("16018000000000000000000"), {from: accounts[5], value: web3.utils.toWei("0")})
    console.log("21")
    console.log(result[21])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[22] = await instance.transfer(accounts[4], web3.utils.toBN("111000000000000000000000"), {from: accounts[12], value: web3.utils.toWei("0")})
    console.log("22")
    console.log(result[22])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[23] = await instance.transfer(accounts[4], web3.utils.toBN("35000000000000000000000"), {from: accounts[10], value: web3.utils.toWei("0")})
    console.log("23")
    console.log(result[23])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[24] = await instance.transfer(accounts[4], web3.utils.toBN("370000000000000000000000"), {from: accounts[17], value: web3.utils.toWei("0")})
    console.log("24")
    console.log(result[24])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[25] = await instance.transfer(accounts[4], web3.utils.toBN("400000000000000000000000"), {from: accounts[19], value: web3.utils.toWei("0")})
    console.log("25")
    console.log(result[25])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[26] = await instance.transfer(accounts[4], web3.utils.toBN("37000000000000000000000"), {from: accounts[11], value: web3.utils.toWei("0")})
    console.log("26")
    console.log(result[26])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[27] = await instance.transfer(accounts[4], web3.utils.toBN("74100000000000000000000"), {from: accounts[20], value: web3.utils.toWei("0")})
    console.log("27")
    console.log(result[27])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[28] = await instance.transfer(accounts[16], web3.utils.toBN("500000815000000000000000"), {from: accounts[14], value: web3.utils.toWei("0")})
    console.log("28")
    console.log(result[28])
    }
    catch(error){
      console.log(error)
    };
  }
catch(error) {
console.log(error)
  }
  callback()
}
