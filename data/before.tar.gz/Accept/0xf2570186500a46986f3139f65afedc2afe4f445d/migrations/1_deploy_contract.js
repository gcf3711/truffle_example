const RealOldFuckMaker = artifacts.require("RealOldFuckMaker");
module.exports = function(deployer, network, accounts) {
deployer.deploy(RealOldFuckMaker)
};
