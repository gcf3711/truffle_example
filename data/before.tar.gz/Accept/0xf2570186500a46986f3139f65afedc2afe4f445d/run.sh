#!/bin/bash
truffle compile
truffle migrate --network develop
truffle exec ./RealOldFuckMakertest.js --network develop > result.txt
