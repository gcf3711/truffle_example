const EBU = artifacts.require("EBU");
module.exports = function(deployer, network, accounts) {
deployer.deploy(EBU)
};
