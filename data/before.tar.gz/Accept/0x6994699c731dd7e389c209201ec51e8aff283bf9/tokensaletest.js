const tokensale = artifacts.require("tokensale")
module.exports = async function(callback) {
  try {
    await web3.eth.getAccounts().then(function (acc){accounts = acc})
    result = []
    instance = await tokensale.deployed()
    address = await tokensale.address
    try{
      result[1] = await web3.eth.sendTransaction({to: address, from: accounts[5], value: web3.utils.toWei("0.001")})
    console.log("1")
    console.log(result[1])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[2] = await web3.eth.sendTransaction({to: address, from: accounts[1], value: web3.utils.toWei("0.169155672427166181")})
    console.log("2")
    console.log(result[2])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[3] = await web3.eth.sendTransaction({to: address, from: accounts[10], value: web3.utils.toWei("3.5")})
    console.log("3")
    console.log(result[3])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[4] = await web3.eth.sendTransaction({to: address, from: accounts[1], value: web3.utils.toWei("0.09")})
    console.log("4")
    console.log(result[4])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[5] = await web3.eth.sendTransaction({to: address, from: accounts[11], value: web3.utils.toWei("50")})
    console.log("5")
    console.log(result[5])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[6] = await web3.eth.sendTransaction({to: address, from: accounts[8], value: web3.utils.toWei("1")})
    console.log("6")
    console.log(result[6])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[7] = await web3.eth.sendTransaction({to: address, from: accounts[7], value: web3.utils.toWei("0.004")})
    console.log("7")
    console.log(result[7])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[8] = await web3.eth.sendTransaction({to: address, from: accounts[3], value: web3.utils.toWei("4.29")})
    console.log("8")
    console.log(result[8])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[9] = await web3.eth.sendTransaction({to: address, from: accounts[19], value: web3.utils.toWei("0.4")})
    console.log("9")
    console.log(result[9])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[10] = await web3.eth.sendTransaction({to: address, from: accounts[21], value: web3.utils.toWei("0.25")})
    console.log("10")
    console.log(result[10])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[11] = await web3.eth.sendTransaction({to: address, from: accounts[13], value: web3.utils.toWei("3")})
    console.log("11")
    console.log(result[11])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[12] = await web3.eth.sendTransaction({to: address, from: accounts[16], value: web3.utils.toWei("0.4")})
    console.log("12")
    console.log(result[12])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[13] = await web3.eth.sendTransaction({to: address, from: accounts[16], value: web3.utils.toWei("0.4")})
    console.log("13")
    console.log(result[13])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[14] = await web3.eth.sendTransaction({to: address, from: accounts[13], value: web3.utils.toWei("2")})
    console.log("14")
    console.log(result[14])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[15] = await web3.eth.sendTransaction({to: address, from: accounts[18], value: web3.utils.toWei("1")})
    console.log("15")
    console.log(result[15])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[16] = await instance.withdraw(web3.utils.toBN("15000000000000000000"), {from: accounts[0], value: web3.utils.toWei("0")})
    console.log("16")
    console.log(result[16])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[17] = await instance.0x6709b337({from: accounts[6], value: web3.utils.toWei("0")})
    console.log("17")
    console.log(result[17])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[18] = await instance.withdraw(web3.utils.toBN("18000000000000000000"), {from: accounts[0], value: web3.utils.toWei("0")})
    console.log("18")
    console.log(result[18])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[19] = await web3.eth.sendTransaction({to: address, from: accounts[4], value: web3.utils.toWei("0.5")})
    console.log("19")
    console.log(result[19])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[20] = await web3.eth.sendTransaction({to: address, from: accounts[14], value: web3.utils.toWei("0.49")})
    console.log("20")
    console.log(result[20])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[21] = await web3.eth.sendTransaction({to: address, from: accounts[2], value: web3.utils.toWei("0.485")})
    console.log("21")
    console.log(result[21])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[22] = await web3.eth.sendTransaction({to: address, from: accounts[15], value: web3.utils.toWei("5")})
    console.log("22")
    console.log(result[22])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[23] = await web3.eth.sendTransaction({to: address, from: accounts[15], value: web3.utils.toWei("10")})
    console.log("23")
    console.log(result[23])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[24] = await web3.eth.sendTransaction({to: address, from: accounts[15], value: web3.utils.toWei("5")})
    console.log("24")
    console.log(result[24])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[25] = await web3.eth.sendTransaction({to: address, from: accounts[15], value: web3.utils.toWei("5")})
    console.log("25")
    console.log(result[25])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[26] = await web3.eth.sendTransaction({to: address, from: accounts[9], value: web3.utils.toWei("0.5")})
    console.log("26")
    console.log(result[26])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[27] = await instance.endPresale({from: accounts[0], value: web3.utils.toWei("0")})
    console.log("27")
    console.log(result[27])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[28] = await instance.transfer(accounts[20], web3.utils.toBN("3635940"), {from: accounts[13], value: web3.utils.toWei("0")})
    console.log("28")
    console.log(result[28])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[29] = await instance.transfer(accounts[20], web3.utils.toBN("3635940"), {from: accounts[13], value: web3.utils.toWei("0")})
    console.log("29")
    console.log(result[29])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[30] = await instance.transfer(accounts[12], web3.utils.toBN("36359419"), {from: accounts[11], value: web3.utils.toWei("0")})
    console.log("30")
    console.log(result[30])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[31] = await instance.transfer(accounts[12], web3.utils.toBN("36359419"), {from: accounts[11], value: web3.utils.toWei("0")})
    console.log("31")
    console.log(result[31])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[32] = await instance.transfer(accounts[12], web3.utils.toBN("36359419"), {from: accounts[11], value: web3.utils.toWei("0")})
    console.log("32")
    console.log(result[32])
    }
    catch(error){
      console.log(error)
    };
    try{
      result[33] = await instance.transfer(accounts[22], web3.utils.toBN("55000"), {from: accounts[1], value: web3.utils.toWei("0")})
    console.log("33")
    console.log(result[33])
    }
    catch(error){
      console.log(error)
    };
  }
catch(error) {
console.log(error)
  }
  callback()
}
