const Play2LivePromo = artifacts.require("Play2LivePromo");
module.exports = function(deployer, network, accounts) {
deployer.deploy(Play2LivePromo)
};
