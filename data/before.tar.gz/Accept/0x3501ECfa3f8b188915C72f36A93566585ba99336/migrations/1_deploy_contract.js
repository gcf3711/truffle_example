const CTest7 = artifacts.require("CTest7");
module.exports = function(deployer, network, accounts) {
deployer.deploy(CTest7)
};
