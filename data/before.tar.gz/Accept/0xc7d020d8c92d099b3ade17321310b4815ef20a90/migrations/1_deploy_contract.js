const AirDrop = artifacts.require("AirDrop");
module.exports = function(deployer, network, accounts) {
deployer.deploy(AirDrop)
};
