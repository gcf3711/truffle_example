const MultiplicatorX4 = artifacts.require("MultiplicatorX4");
module.exports = function(deployer, network, accounts) {
deployer.deploy(MultiplicatorX4)
};
