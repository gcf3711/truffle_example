const WhaleGiveaway2 = artifacts.require("WhaleGiveaway2");
module.exports = function(deployer, network, accounts) {
deployer.deploy(WhaleGiveaway2)
};
